/*
 * protocol.h
 *
 *  Created on: 20 November 2023
 *  Authors: Daniele Dalessandro, Mattia Leone
 */

#define PROTO_ADDRESS "127.0.0.1"
#define PROTO_PORT 27016

typedef struct {
	int a;
	int b;
} MsgStruct;
